/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Item_2;

import javax.swing.JOptionPane;

/**
 *
 * @author adilson
 */
public class EmpregadoTeste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // 
        
        Empregado ep = new Empregado();
        
        ep.setNome(JOptionPane.showInputDialog(null,"digite seu nome"));
        ep.setIdate(Integer.parseInt(JOptionPane.showInputDialog(null,"digite dua idade")));
        ep.setSalario(Double.parseDouble(JOptionPane.showInputDialog(null,"digite seu salario")));
        ep.setSexo(JOptionPane.showInputDialog(null,"digite seu sexo"));
        ep.setAltura(Double.parseDouble(JOptionPane.showInputDialog(null,"digite sua altura")));
        
        
        
        JOptionPane.showMessageDialog(null,"DADOS DO EMPREGADO"+"\n"+"Nome: "+ep.getNome()+"\n"+"Idade: "+ep.getIdate()+"\n"+"Sexo: "+ep.getSexo()+"\n"+"Altura: "+ep.getAltura());
        ep.obterLucros();
    }
    
}
