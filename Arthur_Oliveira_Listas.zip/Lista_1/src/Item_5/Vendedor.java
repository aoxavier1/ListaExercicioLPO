/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Item_5;

import Item_2.Empregado;
import javax.swing.JOptionPane;

/**
 *
 * @author adilson
 */
public class Vendedor extends Empregado {
    
    private double Vendas;
    private int porcentagem;
    private double Comissão;

    public Vendedor() {
    }

    public Vendedor(double Vendas, int porcentagem, double salario, String nome, int idate, double altura, String sexo) {
        super(salario, nome, idate, altura, sexo);
        this.Vendas = Vendas;
        this.porcentagem = porcentagem;
    }

    

    public double getValorVendas() {
        return Vendas;
    }

    public void setValorVendas(double valorVendas) {
        this.Vendas = valorVendas;
    }

    public double getComissao() {
        return Comissão;
    }

    public void setComissao(double comissao) {
        this.Comissão = Comissão;
    }

    public int getPorcentagem() {
        return porcentagem;
    }

    public void setPorcentagem(int porcentagem) {
        this.porcentagem = porcentagem;
    }
    
    @Override
    public void obterLucros() {
        setComissao(((getValorVendas()*getPorcentagem())/100)+getSalario()); 
        JOptionPane.showMessageDialog(null,"Lucros do Vendedor: "+getComissao());
    }
    
}
