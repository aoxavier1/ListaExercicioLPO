/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Item_1;

import javax.swing.JOptionPane;

/**
 *
 * @author adilson
 */
public class CockerTeste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // clase para testar as funcionalidades
        Cocker ck = new Cocker();
        
        ck.setNome((JOptionPane.showInputDialog("Qual o nome do cachorro?")));
        ck.setRaca((JOptionPane.showInputDialog("Qual a raça do cachorro?")));
        ck.setCor((JOptionPane.showInputDialog("Qual a cor do cachorro?")));
        ck.setTipo((JOptionPane.showInputDialog("Qual o tipo do cachorro?")));
        System.out.println("------------------------");
        System.out.println("DADOS SOBRE O CACHORRO");
        System.out.println("------------------------");
        System.out.println(ck.getNome());
        System.out.println(ck.getRaca());
        System.out.println(ck.getCor());
        System.out.println(ck.getTipo());
        ck.precisaTosa();
        
    }
    
}
