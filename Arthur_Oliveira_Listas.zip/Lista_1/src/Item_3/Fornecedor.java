/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Item_3;

import Item_2.Pessoa;
import javax.swing.JOptionPane;

/**
 *
 * @author adilson
 */
public class Fornecedor extends Pessoa {
    
    private double creditom;
    private double valorDivida;
    private double Diferença;
    public Fornecedor() {
    }

    public Fornecedor(double creditoMaximo, double valorEmDivida, String nome, int idate, double altura, String sexo) {
        super(nome, idate, altura, sexo);
        this.creditom = creditoMaximo;
        this.valorDivida = valorEmDivida;
    }

    public double getCreditoMaximo() {
        return creditom;
    }

    public void setCreditoMaximo(double creditoMaximo) {
        this.creditom = creditoMaximo;
    }

    public double getValorEmDivida() {
        return valorDivida;
    }

    public void setValorEmDivida(double valorEmDivida) {
        this.valorDivida = valorEmDivida;
    }

    public double getDiferenca() {
        return Diferença;
    }

    public void setDiferenca(double diferenca) {
        this.Diferença = diferenca;
    }
    
    
    public void obterSaldo(){
       setDiferenca(getCreditoMaximo() - getValorEmDivida());
       
       JOptionPane.showMessageDialog(null,"Saldo disponível: "+getDiferenca());
    }
    
}
