package view;

import controller.GerarAluguel;
import java.util.*;
import javax.swing.JOptionPane;
import model.*;

public class Principal {
    public static void main(String[] args){
        
            Scanner sc = new Scanner(System.in);
            
            ArrayList <AluguelAutomovel> alugueis = new ArrayList<>();
            ArrayList <Pessoa> pessoas= new ArrayList<>();
            ArrayList <Automovel> automoveis= new ArrayList<>();
            int resposta;
            
            do{
               System.out.println("Escolha uma opção:\n 1 - Cadastrar Pessoa:\n2 - Cadastrar Automóvel:\n3 - Criar Aluguel:\n4 - Sair");
                resposta = sc.nextInt();
            switch (resposta){
                case 1: 
                    
                   System.out.println("Deseja cadastrar: \n 1 - Funcionario\n 2 - Cliente");
                    int opcao = sc.nextInt();
                    if(opcao == 1){
                         Funcionario f = new Funcionario();
                         System.out.println("Nome: ");
                         f.setNome(sc.next());
                         System.out.println("CPF: ");
                         f.setCpf(sc.nextInt());
                         System.out.println("Idade:");
                         f.setIdade(sc.nextInt());
                         System.out.println("Altura:");
                         f.setAltura(sc.nextDouble());
                         pessoas.add(f);
                         break;
                    }else if(opcao == 2){
                         Cliente c = new Cliente();
                         System.out.println("Nome: ");
                         c.setNome(sc.next());
                         System.out.println("CPF: ");
                         c.setCpf(sc.nextInt());
                         System.out.println("Idade:");
                         c.setIdade(sc.nextInt());
                         System.out.println("Altura:");
                         c.setAltura(sc.nextDouble());
                         pessoas.add(c);
                         break;
                    }
                break;
                case 2 : 
                   
                   System.out.println("Deseja cadastrar: \n 1 - Carro\n 2 - Caminhão");
                    int opc = sc.nextInt();
                    if(opc == 1){
                         Carro cr = new Carro();
                         System.out.println("Modelo: ");
                         cr.setModelo(sc.next());
                         System.out.println("Marca: ");
                         cr.setMarca(sc.next());
                         System.out.println("Cor:");
                         cr.setCor(sc.next());
                         System.out.println("Tipo:");
                         cr.setTipo(sc.next());
                         System.out.println("Km Rodado:");
                         cr.setkmRodado(sc.nextInt());
                         automoveis.add(cr);
                         break;
                    }else if(opc == 2){
                         Caminhao cam = new Caminhao();
                         System.out.println("Nome: ");
                         cam.setModelo(sc.next());
                         System.out.println("CPF: ");
                         cam.setMarca(sc.next());
                         System.out.println("Idade:");
                         cam.setCor(sc.next());
                         System.out.println("Tipo:");
                         cam.setTipo(sc.next());
                         System.out.println("Km Rodado:");
                         cam.setkmRodado(sc.nextInt());
                         automoveis.add(cam);
                         break;
            }
                
                case 3 : 
                    
                    int ps = Integer.parseInt(JOptionPane.showInputDialog("Qual a posição da pessoa?"));
                    int cs = Integer.parseInt(JOptionPane.showInputDialog("Qual a posição do carro?"));
                    int tip = Integer.parseInt(JOptionPane.showInputDialog("Qual o tipo de Aluguel:\n 1: Diaria\n2: Mensal"));
                    
                    if(tip == 1){
                        GerarAluguel ga1 = new GerarAluguel();
                        alugueis.add(ga1.calcularAluguel((Cliente) pessoas.get(ps), (Carro) automoveis.get(cs), "Diaria"));                     
                    }
                    else if(tip == 2){
                        GerarAluguel ga1 = new GerarAluguel();
                        ga1.calcularAluguel((Cliente) pessoas.get(ps), (Carro) automoveis.get(cs), "Mensal");
                    }
                    break;
        
            }
               
            }while(resposta != 4);
    }
}
    
    
            
    

