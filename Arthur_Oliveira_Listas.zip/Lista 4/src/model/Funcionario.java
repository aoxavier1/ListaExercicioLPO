/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author aluno
 */

public class  Funcionario extends Pessoa {
    protected int cpf;

    public Funcionario(int cpf, String nome, double altura, int idade) {
        super(nome, altura, idade);
        this.cpf = cpf;
    }

    public Funcionario(String nome, double altura, int idade) {
        super(nome, altura, idade);
    }

    public Funcionario() {
        super();
    }

  
    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }


    
    
    
}

