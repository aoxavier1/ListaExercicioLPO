/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author aluno
 */
public class Caminhao extends Automovel{
    private String modelo;
    private String marca;
    private String cor;

    public Caminhao(String modelo, String marca, String cor) {
       super();
        this.modelo = modelo;
        this.marca = marca;
        this.cor = cor;
    }

    public Caminhao() {
    }
    

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getCor() {
        return cor;
    }
    
}